//
//  MLJSelectView.m
//  LMMPickerViewSample
//
//  Created by 茅露军 on 2017/1/23.
//  Copyright © 2017年 LMM. All rights reserved.
//

#import "MLJSelectView.h"
@interface MLJSelectView () <UIPickerViewDelegate,UIPickerViewDataSource>

@property (strong, nonatomic) NSDictionary *pickerDic;
@property (strong, nonatomic) NSArray *selectedArray;
@property (strong, nonatomic) NSArray *provinceArray;
@property (strong, nonatomic) NSArray *cityArray;
@property (strong, nonatomic) NSArray *townArray;
@property (strong, nonatomic) UIPickerView *pickView;
@end
@implementation MLJSelectView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
        [self getAddressInformation];
        [self setBaseView];
    }
    return self;
}
- (void)getAddressInformation {
    NSBundle *budle = [NSBundle mainBundle];
    
    NSString *plistPath = [budle pathForResource:@"provinces_cities" ofType:@"plist"];
    
    //    获取属性列表文件中的全部数据
    NSDictionary *dict = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    
    self.pickerData = dict;
    
    //    省份名数据
    self.pickerProvinceData = [self.pickerData allKeys];
    
    //    默认去除取出第一个省的所有市的数据
    NSString *selectedProvince = [self.pickerProvinceData objectAtIndex:0];
    
    self.pickerCitiesData = [self.pickerData objectForKey:selectedProvince];
    
    
}
- (void)setBaseView {
    
    _pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(15, 20, self.frame.size.width-30, 250)];
    
    [self addSubview:_pickerView];
    
    self.pickerView.delegate = self;
    
    self.pickerView.dataSource = self;
}

- (NSArray *)dataSourceForDayComponent{
    if(!_dataSourceForDayComponent){
        NSMutableArray *arr = [NSMutableArray array];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setLocale:[NSLocale localeWithLocaleIdentifier:@"zh_CN"]];
        [formatter setDateFormat:@"yyyy-MM-dd"];
        NSString *str = [NSString stringWithFormat:@"%@ 00:00:00",[formatter stringFromDate:[NSDate date]]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSDate *baseDate = [formatter dateFromString:str];
        NSLog(@" %@",str);
        for (NSInteger i = 0; i < 30; i++) {
            if(i >= 2){
                NSDate *date = [NSDate dateWithTimeInterval:24*60*60*i sinceDate:baseDate];
                [formatter setDateFormat:@"M月dd日(EE)"];
                NSMutableString *dateStr = [[formatter stringFromDate:date] mutableCopy];
                NSLog(@" %@",dateStr);
                [arr addObject:dateStr];
            }else if(i == 0){
                NSDate *date = [NSDate dateWithTimeInterval:24*60*60*i sinceDate:baseDate];
                [formatter setDateFormat:@"M月dd日"];
                NSMutableString *dateStr = [[formatter stringFromDate:date] mutableCopy];
                [arr addObject:[NSString stringWithFormat:@"%@(今天)",dateStr]];
            }else if (i == 1){
                NSDate *date = [NSDate dateWithTimeInterval:24*60*60*i sinceDate:baseDate];
                [formatter setDateFormat:@"M月dd日"];
                NSMutableString *dateStr = [[formatter stringFromDate:date] mutableCopy];
                [arr addObject:[NSString stringWithFormat:@"%@(明天)",dateStr]];
                
            }
            
        }
        _dataSourceForDayComponent = [arr copy];
    }
    return _dataSourceForDayComponent;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row
          forComponent:(NSInteger)component reusingView:(UIView *)view
{
    UILabel *lbl = (UILabel *)view;
    
    if (lbl == nil) {
        
        lbl = [[UILabel alloc]init];
        
        //在这里设置字体相关属性
        
        lbl.font = [UIFont systemFontOfSize:14];
        
        lbl.textColor = [UIColor redColor];
        
        [lbl setTextAlignment:0];
        
        [lbl setBackgroundColor:[UIColor clearColor]];
    }
    //重新加载lbl的文字内容
    
    lbl.text = [self pickerView:pickerView titleForRow:row forComponent:component];
    
    return lbl;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    
    if (component == 0) {
        return self.frame.size.width / 2 - 40;
    } else if (component == 1) {
        return 80;
    } else {
        return self.frame.size.width / 2 - 40;
    }
    
}


#pragma mark ------ 实现协议UIPickerViewDataSource方法
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 3;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    if (component == 0) {
        
        return self.dataSourceForDayComponent.count;
        
    }else if (component == 1)
    {
        return self.pickerProvinceData.count;
    }else
    {
        return self.pickerCitiesData.count;
    }
    
}

#pragma mark ----- 实现协议UIPickerViewDelegate方法
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component == 0) {
        return [self.dataSourceForDayComponent objectAtIndex:row];
    }
    else if (component == 1) {
        return [self.pickerProvinceData objectAtIndex:row];
    } else {
        return [self.pickerCitiesData objectAtIndex:row];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    if (component == 0) {
        [pickerView reloadComponent:0];
    }
    if (component == 1) {
        NSString *selectedProvince = [self.pickerProvinceData objectAtIndex:row];
        
        NSArray *array = [self.pickerData objectForKey:selectedProvince];
        
        self.pickerCitiesData = array;
        
        [self.pickerView reloadComponent:1];
        [self.pickerView reloadComponent:2];
    }
    
    NSInteger row1 = [self.pickerView selectedRowInComponent:0];
    NSInteger row2 = [self.pickerView selectedRowInComponent:1];
    NSInteger row3 = [self.pickerView selectedRowInComponent:2];
    NSString *selected1 = [self.dataSourceForDayComponent objectAtIndex:row1];
    NSString *selected2 = [self.pickerProvinceData objectAtIndex:row2];
    NSString *selected3 = [self.pickerCitiesData objectAtIndex:row3];
    
    NSLog(@"%@%@%@",selected1,selected2,selected3);
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(getDtae:withMAN:addWithTime:)]) {
        [self.delegate getDtae:selected1 withMAN:selected2 addWithTime:selected3];
    }
    
    
}


@end
