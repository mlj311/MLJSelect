//
//  MLJTwoSelectView.m
//  LMMPickerViewSample
//
//  Created by 茅露军 on 2017/1/23.
//  Copyright © 2017年 LMM. All rights reserved.
//

#import "MLJTwoSelectView.h"
@interface MLJTwoSelectView ()<UIPickerViewDelegate,UIPickerViewDataSource>

@property (strong, nonatomic) UIPickerView *pickView;
@property (strong, nonatomic) NSArray *timeArr;
@end
@implementation MLJTwoSelectView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
        
        [self setBaseView];
    }
    return self;
}
- (void)setBaseView {
    
    _pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(15, 20, self.frame.size.width-30, 250)];
    
    [self addSubview:_pickerView];
    
    self.pickerView.delegate = self;
    
    self.pickerView.dataSource = self;
    
    }
-(NSArray *)timeArr
{
    if (!_timeArr) {
        _timeArr = @[@"09:00"];
    }
    return _timeArr;
}

- (NSArray *)dataSourceForDayComponent{
    if(!_dataSourceForDayComponent){
        NSMutableArray *arr = [NSMutableArray array];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setLocale:[NSLocale localeWithLocaleIdentifier:@"zh_CN"]];
        [formatter setDateFormat:@"yyyy-MM-dd"];
        NSString *str = [NSString stringWithFormat:@"%@ 00:00:00",[formatter stringFromDate:[NSDate date]]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSDate *baseDate = [formatter dateFromString:str];
        NSLog(@" %@",str);
        for (NSInteger i = 0; i < 30; i++) {
            if(i >= 2){
                NSDate *date = [NSDate dateWithTimeInterval:24*60*60*i sinceDate:baseDate];
                [formatter setDateFormat:@"M月dd日(EE)"];
                NSMutableString *dateStr = [[formatter stringFromDate:date] mutableCopy];
                NSLog(@" %@",dateStr);
                [arr addObject:dateStr];
            }else if(i == 0){
                NSDate *date = [NSDate dateWithTimeInterval:24*60*60*i sinceDate:baseDate];
                [formatter setDateFormat:@"M月dd日"];
                NSMutableString *dateStr = [[formatter stringFromDate:date] mutableCopy];
                [arr addObject:[NSString stringWithFormat:@"%@(今天)",dateStr]];
            }else if (i == 1){
                NSDate *date = [NSDate dateWithTimeInterval:24*60*60*i sinceDate:baseDate];
                [formatter setDateFormat:@"M月dd日"];
                NSMutableString *dateStr = [[formatter stringFromDate:date] mutableCopy];
                [arr addObject:[NSString stringWithFormat:@"%@(明天)",dateStr]];
                
            }
            
        }
        _dataSourceForDayComponent = [arr copy];
    }
    return _dataSourceForDayComponent;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row
          forComponent:(NSInteger)component reusingView:(UIView *)view
{
    UILabel *lbl = (UILabel *)view;
    
    if (lbl == nil) {
        
        lbl = [[UILabel alloc]init];
        
        //在这里设置字体相关属性
        
        lbl.font = [UIFont systemFontOfSize:14];
        
        lbl.textColor = [UIColor blackColor];
        
        [lbl setTextAlignment:0];
        
        [lbl setBackgroundColor:[UIColor clearColor]];
    }
    //重新加载lbl的文字内容
    
    lbl.text = [self pickerView:pickerView titleForRow:row forComponent:component];
    
    return lbl;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    
    
    return self.frame.size.width / 2 ;
    
}


#pragma mark ------ 实现协议UIPickerViewDataSource方法
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    if (component == 0) {
        
        return self.dataSourceForDayComponent.count;
        
    }
    {
        return self.timeArr.count;
    }
    
}

#pragma mark ----- 实现协议UIPickerViewDelegate方法
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component == 0) {
        return [self.dataSourceForDayComponent objectAtIndex:row];
    }
     else {
        return [self.timeArr objectAtIndex:row];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    if (component == 0) {
        [pickerView reloadComponent:0];
    }
    else {
        
        [self.pickerView reloadComponent:1];
        [self.pickerView reloadComponent:2];
    }
    
    NSInteger row1 = [self.pickerView selectedRowInComponent:0];
    NSInteger row2 = [self.pickerView selectedRowInComponent:1];
    NSString *selected1 = [self.dataSourceForDayComponent objectAtIndex:row1];
    NSString *selected2 = [self.timeArr objectAtIndex:row2];
    
    NSLog(@"%@%@",selected1,selected2);
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(getDtae:AddWithTime:)]) {
        [self.delegate getDtae:selected1 AddWithTime:selected2];
    }
    
    
}

@end
