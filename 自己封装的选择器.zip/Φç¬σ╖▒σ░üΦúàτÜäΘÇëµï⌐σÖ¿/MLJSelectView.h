//
//  MLJSelectView.h
//  LMMPickerViewSample
//
//  Created by 茅露军 on 2017/1/23.
//  Copyright © 2017年 LMM. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol MLJDelegate <NSObject>
-(void)getDtae:(NSString *)date withMAN:(NSString *)man addWithTime:(NSString *)time;

@end

@interface MLJSelectView : UIView
@property (nonatomic, weak) id<MLJDelegate> delegate;

@property (nonatomic,strong) UIPickerView *pickerView;
@property (nonatomic,strong) UILabel *label;

@property (nonatomic,strong) NSDictionary *pickerData;        //保存全部数据
@property (nonatomic,strong) NSArray *pickerProvinceData;     //当前的省数据
@property (nonatomic,strong) NSArray *pickerCitiesData;       //当前省下面的市数据
@property (strong, nonatomic) NSArray *dataSourceForDayComponent;

@end
