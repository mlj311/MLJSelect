//
//  MLJTwoSelectView.h
//  LMMPickerViewSample
//
//  Created by 茅露军 on 2017/1/23.
//  Copyright © 2017年 LMM. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol MLJTwoSelectDelegate <NSObject>
-(void)getDtae:(NSString *)date  AddWithTime:(NSString *)time;

@end
@interface MLJTwoSelectView : UIView
@property (nonatomic, weak) id<MLJTwoSelectDelegate> delegate;

@property (nonatomic,strong) UIPickerView *pickerView;
@property (strong, nonatomic) NSArray *dataSourceForDayComponent;
@end
